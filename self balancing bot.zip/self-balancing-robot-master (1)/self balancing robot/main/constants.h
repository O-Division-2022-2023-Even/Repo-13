#ifndef CONSTANTS_H
#define CONSTANTS_H

double KP=3.25;
double KI=0;
double KD=0.55;

#define MAX_ACCEL 50

#define P1_X 500
#define P1_Y 2

#define P2_X 0
#define P2_Y 30

#endif



