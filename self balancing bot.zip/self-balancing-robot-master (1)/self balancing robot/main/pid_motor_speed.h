#pragma once

extern void setup_pid();
extern void get_pid_motor_speed(int16_t *, float, float, int16_t, int16_t);
