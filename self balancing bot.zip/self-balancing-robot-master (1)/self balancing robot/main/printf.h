#ifndef PRINT_H
#define PRINT_H


extern void prints(char *fmt, ... );
extern void printsf(const char *, char * fmt, ...);
#endif
